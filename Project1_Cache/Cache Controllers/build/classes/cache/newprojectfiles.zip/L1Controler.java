/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Lakshman
 */
public class L1Controler {

    Queues ques;
    L1Victim l1v=new L1Victim();
    WriteBuff wb=new WriteBuff();

    public L1Controler(Queues que) {
        this.ques = que;
    }
    int i = 0, k = 0;
    String[] c;

    public String[][] L1cache = new String[128][2];
    public boolean[][] vb = new boolean[128][2];
    public boolean[][] db = new boolean[128][2];
    public int[][] loc = new int[128][2];
    List<String> tempList = new ArrayList<String>();
    List<String> tempList_avict = new ArrayList<String>();
    List<String> Instr;
    String s;

    public void readfromq() {
        //System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
        System.out.println("in L1C");
        L1cache[42][1]="10101";
        vb[42][1]=true;
        int count = 0;
        Instr = ques.getCPU2L1ConQueue();
        int n = Instr.size();
        s = Instr.get(0);//get the ith item of the list anf store it in a string
        while (!ques.getCPU2L1ConQueue().isEmpty() && count < 1&& (s.contains("Instruction") || s.contains("instruction"))) {
            if (s.contains("Instruction") || s.contains("instruction")) {
                count++;
                // System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
                ques.getCPU2L1ConQueue().remove(0);

            }
        }
         // System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
            s = Instr.get(0);
            //  System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
            tempList.add(s);
           // System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
           // System.out.println("i am in L!C checking templist************ "+ tempList.get(0) );
           System.out.println(tempList.get(0) + " this is s***************");
            c = s.split(" "); // as the input format is Read " " address i am spliting it into 2 halfs 
            //storing the binary address into an integer
            System.out.println("i am c of zero" + c[0]);
             // System.out.println("In K==1** " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
            k = B2Iconvert(c);// converting it to inter to get array index.
            System.out.println("conversion also done");
             // System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
        

    }

    public int B2Iconvert(String[] d) {
        int tag, index, offset;
        System.out.println("in method to convert  ***"+d.length);
        String a, b, c, address;
        a = d[1].substring(0, 5);
        b = d[1].substring(5, 12);
        c = d[1].substring(12, 16);

        tag = Integer.parseInt(a, 2);
        index = Integer.parseInt(b, 2);
        System.out.println("index is " + index);
        offset = Integer.parseInt(c, 2);
        if (d[0].equalsIgnoreCase("Load")) {
            if(d.length==3){
           // System.out.println("In K==1 " + ques.getL1CtoL2CQueue()+"L!D"+ques.getL1CtoL1DQueue());
            k = read(a, b, c, tag, index, offset,d[1]);
          //  tempList.remove(0);
            ques.getCPU2L1ConQueue().remove(0);
            System.out.println("checking done");
            
            }
            else{// need to see if i get the data from L2C*************
                System.out.println("writing data to L1d which got from L2c");
            storeaftermiss(a, b, c, tag, index, offset);
            tempList.add(d[3]);//sending the string to CPU to print.
            ques.getL2CtoL1CQueue().remove(0);
            ques.setL1CtoCPUQueue(tempList);
            }
        } else if (d[0].equalsIgnoreCase("Store")) {
            
                System.out.println("this call is from CPU **********");
                store(a, b, c, tag, index, offset);
                //tempList.remove(0);
                ques.getCPU2L1ConQueue().remove(0);
                System.out.println("in L1D"+ques.getL1CtoL1DQueue().get(0));
            
        }
        else{
            
        }
        return index;
    }

    public int read(String a, String b, String c, int tag, int index, int offset, String add) {
        if ((a.equals(L1cache[index][0])) && (vb[index][0] == true)) {
            System.out.println("tag matched so checking in L1d"+L1cache[index][0]+"    "+ L1cache[index][1]);
            ques.setL1CtoL1DQueue(tempList);
              System.out.println("hi"+ques.getL1CtoL1DQueue());
            return 0;
        } 
        else if ((a.equals(L1cache[index][1])) && (vb[index][1] == true)) 
        {
            System.out.println("tag matched so checking in L1d");
            ques.setL1CtoL1DQueue(tempList);
            System.out.println("hi"+ques.getL1CtoL1DQueue());
            return 0;
        } 
        else 
        {
            System.out.println("checking in L1_victim cache");
            String t = l1v.victimcache(a, offset);
           // System.out.println(t);
            if (t!=null)
            {
                ques.setL1CtoCPUQueue(tempList);
                return 0;
            }
            else
            {
                System.out.println("checking in L1_Data buffer");
                t = wb.bufferload(a, offset);
                //System.out.println(t);
                if (t!=null) {
                    ques.setL1CtoCPUQueue(tempList);
                    return 0;
                } 
                else
                {
                    System.out.println("checking in L2cache");
                    ques.setL1CtoL2CQueue(tempList);
                    return 1;
                }
            }

        }
   }
    public int store(String a, String b, String c, int tag, int index, int offset) {
        System.out.println("in store from CPU**********");
        if(vb[index][0]==false){
            vb[index][0]=true;
            L1cache[index][0]=a;
            db[index][0]=false;
            ques.setL1CtoL1DQueue(tempList);
            System.out.println("i kept in L1D");
            return 0;
        }
        else if(vb[index][1]==false){
            vb[index][1]=true;
            L1cache[index][1]=a;
            db[index][1]=false;
            ques.setL1CtoL1DQueue(tempList);
            return 0;
        }
        else{
            String tag1,send_data;
            tag1=L1cache[index][0];
            send_data="Evict ".concat(tag1);
            send_data=send_data.concat(b);
            send_data=send_data.concat("00000 ");
            if(!db[index][0]){
                send_data=send_data.concat("0");
            }else{
                send_data=send_data.concat("1");
            }
            db[index][0]=true;
            L1cache[index][0]=a;
            tempList_avict.add(send_data);
            ques.setL1CtoL1DQueue(tempList_avict);
            tempList_avict.remove(0);
            ques.setL1CtoL1DQueue(tempList);
            
        }
       
    return 0;
    }
    
    public void storeaftermiss(String a, String b, String c, int tag, int index, int offset){
        System.out.println("in store from L2c**********");
        if(vb[index][0]==false){
            vb[index][0]=true;
            L1cache[index][0]=a;
            db[index][0]=false;
            ques.setL1CtoL1DQueue(tempList);
            
        }
        else if(vb[index][1]==false){
            vb[index][1]=true;
            L1cache[index][1]=a;
            db[index][1]=false;
            ques.setL1CtoL1DQueue(tempList);
           
        }
        else{
            String tag1,send_data;
            tag1=L1cache[index][0];
            send_data="Evict ".concat(tag1);
            send_data=send_data.concat(b);
            send_data=send_data.concat("00000 ");
            if(!db[index][0]){
                send_data=send_data.concat("0");
            }else{
                send_data=send_data.concat("1");
            }
         
            L1cache[index][0]=a;
            tempList_avict.add(send_data);
            ques.setL1CtoL1DQueue(tempList_avict);
            tempList_avict.remove(0);
            ques.setL1CtoL1DQueue(tempList);
            
        }
        
    }
}
