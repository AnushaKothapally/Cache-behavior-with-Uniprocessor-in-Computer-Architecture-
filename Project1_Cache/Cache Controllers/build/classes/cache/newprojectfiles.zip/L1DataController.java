/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author srishailamdasari1
 */
public class L1DataController {
    Queues queueline;
    String data;
    String cachesize[][]=new String[128][2];
     String datacache[][]=new String[128][2];
    L1DataController(Queues que){
       this.queueline=que;
    }
    public void L1DataToL1Controller(){
     System.out.println("i Ma in L1D now ");
        datacache[42][0]="CD";
        cachesize[42][0]="10101";
         cachesize[127][0]="01011";
         datacache[127][0]="AB";
       System.out.println("in L1D"+queueline.getL1CtoL1DQueue().get(0));  
       String st=queueline.getL1CtoL1DQueue().get(0);
       System.out.println("in L1D"+queueline.getL1CtoL1DQueue().get(0));
     //  st="evict 01011111111100000";
       String instruction[]=st.split(" ",0);
       List tempList=new ArrayList();
       //System.out.println("Instruction about to excuted is "+queueline.getL1CtoL1DQueue().get(0));
       
       switch(instruction[0]){
           case "Load":
                System.out.println("Current instruction is:  "+st);
               String tag=instruction[1].substring(0, 5);
               int offset= Integer.parseInt(instruction[1].substring(12,17));
               int location=Integer.parseInt(instruction[1].substring(5, 12),2);
               //System.out.println(location+"  ");
               System.out.println("Hello"+tag+cachesize[location][0]+location+datacache[location][0]);
               if(tag.equalsIgnoreCase(cachesize[location][0])){
                   data=datacache[location][0];
                  
               }
               else if(tag.equalsIgnoreCase(cachesize[location][1])){
                    System.out.println("Hello"+data);
                   data=datacache[location][1];
               }
                System.out.println("Hello"+data);
               // data=!(data.equals(null))?data.substring(offset,offset+Integer.parseInt(instruction[2])):" ";
                System.out.println("Data read from L1D is: "+data+" for instrction"+instruction[0]);
                tempList.add(data);         
                queueline.setL1DtoL1CQueue(tempList);
               // System.out.println("Data read is"+queueline.getL1DtoL1CQueue().get(0));
                queueline.getL1CtoL1DQueue().remove(0);
//                for(String st1: queueline.getL1DtoL1CQueue()){
//                System.out.println(" Data in L1D2L1C Queue :"+st1);
//                }
                
                for(String st1: queueline.getL1CtoL1DQueue()){
                System.out.println("Remaining instructions in L1C2L1DQueue are: "+st1);
                }   
             break;
           case "Store":
               System.out.println("i am store of L1D");
               String tag1=instruction[1].substring(0, 5);
               int offset1= Integer.parseInt(instruction[1].substring(12,17));
               int location1=Integer.parseInt(instruction[1].substring(5, 12),2);
               String value=instruction[2];
               
               if(null==datacache[location1][0]){
               datacache[location1][0]=value;
               cachesize[location1][0]=tag1;
               }
               else if(null==datacache[location1][0]){
               datacache[location1][1]=value;
                cachesize[location1][0]=tag1;
               } 
              System.out.println("Value has been stored in L1DataCache: Data is - "+ datacache[location1][0]+" for instrction"+instruction[0]+location1); 
              queueline.getL1CtoL1DQueue().remove(0);   
              System.out.println("hi");
              break;
       case "Evict":
            String tag2=instruction[1].substring(0, 5);
            int offset2= Integer.parseInt(instruction[1].substring(12,17),2);
            int location2=Integer.parseInt(instruction[1].substring(5, 12),2);
            int dirtybit=Integer.parseInt(instruction[2]);
            if(dirtybit==0){
                  if (tag2.equalsIgnoreCase(cachesize[location2][0])) {
                    data = datacache[location2][0];

                } else if (tag2.equalsIgnoreCase(cachesize[location2][1])) {
                    data = datacache[location2][1];
                }
                // data=!(data.equals(null))?data.substring(offset2,offset2+Integer.parseInt(instruction[2])):" ";
                L1Victim v = new L1Victim();
                Boolean result = v.victimcachestore(tag2, offset2, data);
                if (result) {
                    System.out.println("Data has been stored into victim cache for instruction" + instruction[0]);
                }
          }
            else if(dirtybit==1) {
                if (tag2.equalsIgnoreCase(cachesize[location2][0])) {
                    data = datacache[location2][0];

                } else if (tag2.equalsIgnoreCase(cachesize[location2][1])) {
                    data = datacache[location2][1];
                }
                // data=!(data.equals(null))?data.substring(offset2,offset2+Integer.parseInt(instruction[2])):" ";
                WriteBuffer v = new WriteBuffer();
                Boolean result = v.storebuffer(tag2, offset2, data);
                if (result) {
                    System.out.println("Data has been stored into Write Buffer cache for instruction" + instruction[0]);
                }
            }
          break;
       } 
    }
}
