/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lakshman
 */
class L2Controler {
    Queues ques;
     L1Victim l1v=new L1Victim();
    WriteBuff wb=new WriteBuff();
    L1Controler l1c;
            
    L2Controler(Queues ques) {
        this.ques=ques;
    }
    int i = 0, k = 0;
    String[] c;

    public String[][] L2cache = new String[256][2];

    public boolean[][] vb = new boolean[256][2];
    public boolean[][] db = new boolean[256][2];
    public int[][] loc = new int[256][2];
    List<String> tempList = new ArrayList<String>();
    List<String> tempList_avict = new ArrayList<String>();
    List<String> Instr_l2c;
    public void readfromq(){
        System.out.println("in L2C");
        System.out.println("IN L2C");
        int count = 0;
        Instr_l2c = ques.getL1CtoL2CQueue();
        int n = Instr_l2c.size();
        String s ;//get the ith item of the list anf store it in a string
        
       
        //    System.out.println("this is S in L2"+s);
            s =  ques.getL1CtoL2CQueue().get(0);
            System.out.println("this is S in L2"+s);
            tempList.add(s);
            
            System.out.println("i am in L2C checking templist************ "+ tempList.get(0) );
            System.out.println(s + " this is s***************");
            c = s.split(" "); // as the input format is Read " " address i am spliting it into 3parts 
            //storing the binary address into an integer
            System.out.println("i am c of zero" + c[0]);
            k = B2Iconvert(c);// converting it to inter to get array index.
            System.out.println("conversion in L2 done");
        
    
    
}
    public int B2Iconvert(String[] d) {
        int tag, index, offset;
        System.out.println("in method to convert  ***"+d.length);
        String a, b, c, address;
        a = d[1].substring(0, 4);
        b = d[1].substring(4, 12);
        c = d[1].substring(12, 16);

        tag = Integer.parseInt(a, 2);
        index = Integer.parseInt(b, 2);
        System.out.println("index is " + index);
        offset = Integer.parseInt(c, 2);
        if (d[0].equalsIgnoreCase("Load")) {
            if(d.length==3){
           // k = read(a, b, c, tag, index, offset,d[1]);
            if (k == 1) {
                ques.setL2CtoMemoryQueue(tempList);
                System.out.println("In K==1" + ques.getL2CtoMemoryQueue().size());
            }
            // tempList.remove(0);
            ques.getL1CtoL2CQueue().remove(0);
            System.out.println("i just removed"+ques.getL1CtoL2CQueue());
            
            }
            else{// need to see if i get the data from memory*************
                System.out.println("writing data to L2d which got from memory");
            //storeaftermiss(a, b, c, tag, index, offset);
            tempList_avict=ques.getMemorytoL2CQueue();
            String res=tempList_avict.get(0).concat(d[3]);
            tempList.add(res);//concatinate the string result from CPU to the instruction then pass this to L1c
            tempList_avict.remove(0);
            ques.getMemorytoL2CQueue().remove(0);
            ques.setL2CtoL1CQueue(tempList);
            }
        } else if (d[0].equalsIgnoreCase("Store")) {// i think its not necessary????????????????
            
                System.out.println("this call is from CPU **********");
            //    store(a, b, c, tag, index, offset);
                //ques.getCPU2L1ConQueue().remove(0);
            
        }
        else{
            //l1c.vb
            
        }
        return index;
    }
    
}
