/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

/**
 *
 * @author srishailamdasari1
 */
public class L1Victim {
    String victimcache[][]=new String[2][2];
    String data, storeValue,storeTag,action;
    public String victimcache(String tag,int offset){     
        if (tag.equals(victimcache[0][1])) {
            data = victimcache[0][0];
            return data;

        } else if (tag.equals(victimcache[1][1])) {
            data = victimcache[1][0];
             return data;
        }
        
        return null;
    }
       public boolean victimcachestore(String tag,int offset,String data){
    
     
        storeValue=data;
            if (victimcache[0][0] == null) {
                victimcache[0][0] = storeValue;
                victimcache[0][1] = storeTag;
                 return true;
            }
           else if (victimcache[1][0] == null) {
                victimcache[1][0] = storeValue;
                victimcache[1][1] = storeTag;
                 return true;
            } else {
                //Simply removing the data.
                victimcache[0][0] = storeValue;
                victimcache[0][1] = storeTag;
                 return true;
            }  
    }
}

