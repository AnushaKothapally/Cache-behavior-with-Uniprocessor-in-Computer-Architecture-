/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;


/**
 *
 * @author srishailamdasari1
 */
public class CPUController {
    Queues queueline;
    CPUController(Queues cpuq){
    this.queueline=cpuq;
    }
    public void CPU2L1Move(){
            
            System.out.println("CPUQ size"+queueline.getCPUQueue().size()+" 5 is "+queueline.getCPUQueue().get(1));
            List<String> tempList=new ArrayList<String>();
            int i=0;
            int count=0;
            
        while (!queueline.getCPUQueue().isEmpty()&&count<=1) {
            if ((i < queueline.getCPUQueue().size())&&(!(queueline.getCPUQueue().isEmpty()))) {
            //    System.out.println("******"+queueline.CPUQueue.get(i));
                if(queueline.getCPUQueue().get(i).contains("Instruction")||queueline.getCPUQueue().get(i).contains("instruction")){
                count++;
                }
                if(count!=2){
                String st = queueline.CPUQueue.get(i);
                tempList.add(st);
                queueline.CPUQueue.remove(i);
                }
              
            }
         }
            queueline.setCPU2L1ConQueue(tempList);
//            System.out.println(queueline.CPUQueue.size()+"CPU2L1QUEUE");
//            for (Iterator it = queueline.getCPU2L1ConQueue().iterator(); it.hasNext();) {
//                System.out.println(it.next());
//            }
          
            
       
        
    }
    
public void displayData(){
    String st = queueline.getL1CtoCPUQueue().get(0);
    // String st="Load 10101010101000000 5 ABCDE";
    String[] data = st.split(" ");
    int no_of_bytes = 0;
    if(data.length==4){
    String off = data[1].substring(12, 17);
    int offset = Integer.parseInt(off, 2);
    if (data[0] != null && data[0].equals("Load")) {
        no_of_bytes = Integer.parseInt(data[2]);
        String key;
        key = data[3];
        System.out.println("Data read for instruction: " + data[0] + " " + data[1] + " " + data[2] + " is: "+key);

        for (int i = offset; i < key.length();) {
            for (int j = i; j < i + no_of_bytes;) {
                // System.out.print(j+""+key.length());
                if (j < key.length()) {
                    System.out.print(key.charAt(j));
                }
                j++;
            }
            i = i + no_of_bytes;
            System.out.println("\n");
        }
    queueline.getL1CtoCPUQueue().remove(0);
    }
    }
    else{
        String off = data[2].substring(12, 17);
    int offset = Integer.parseInt(off, 2);
    if (data[0] != null && data[0].equals("Load")) {
        no_of_bytes = Integer.parseInt(data[2]);
        String key;
        key = data[3];
        System.out.println("Data read for instruction: " + data[0] + " " + data[1] + " " + data[2] + " is: "+key);

        for (int i = offset; i < key.length();) {
            for (int j = i; j < i + no_of_bytes;) {
                // System.out.print(j+""+key.length());
                if (j < key.length()) {
                    System.out.print(key.charAt(j));
                }
                j++;
            }
            i = i + no_of_bytes;
            System.out.println("\n");
        }
    queueline.getL1CtoCPUQueue().remove(0);
    }
    }

}
//public static void main(String args[]){
//    Queues ueq=null;
//    CPUController cpu=new CPUController(ueq);
//    cpu.displayData();
//
//}
    
}
