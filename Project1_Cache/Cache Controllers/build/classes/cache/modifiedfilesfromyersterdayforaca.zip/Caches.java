/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cache.controllers;

/**
 *
 * @author Lakshman
 */
public class Caches {
     public String cachesize[][]=new String[128][2];
     public String datacache[][]=new String[128][2];
    
}
